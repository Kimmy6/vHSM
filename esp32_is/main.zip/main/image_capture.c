// image_capture.c
// ESP32-CAM capture + resize + threshold + Von Neumann extraction + SD debug save

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "esp_camera.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "img_converters.h"

#include "sdcard_storage.h"

static const char *TAG = "IMG_CAP";

// ── AI-Thinker ESP32-CAM pin definition ─────────────────────────────────────
#define CAM_PIN_PWDN     32
#define CAM_PIN_RESET    -1   // not wired on AI-Thinker
#define CAM_PIN_XCLK      0
#define CAM_PIN_SIOD     26   // I2C SDA
#define CAM_PIN_SIOC     27   // I2C SCL
#define CAM_PIN_D7       35
#define CAM_PIN_D6       34
#define CAM_PIN_D5       39
#define CAM_PIN_D4       36
#define CAM_PIN_D3       21
#define CAM_PIN_D2       19
#define CAM_PIN_D1       18
#define CAM_PIN_D0        5
#define CAM_PIN_VSYNC    25
#define CAM_PIN_HREF     23
#define CAM_PIN_PCLK     22

#define THRESHOLD_VAL    128
#define JPG_QUALITY       80

// Raw capture resolution: UXGA = 1600x1200
// Processing resolution below can be changed as desired.
#define RESIZE_WIDTH     640
#define RESIZE_HEIGHT    480

static bool s_camera_ready = false;

static esp_err_t save_framebuffer_as_jpeg(camera_fb_t *fb, const char *filename)
{
    if (!sdcard_is_mounted()) {
        return ESP_ERR_INVALID_STATE;
    }

    uint8_t *jpg_buf = NULL;
    size_t jpg_len = 0;
    if (!frame2jpg(fb, JPG_QUALITY, &jpg_buf, &jpg_len)) {
        ESP_LOGE(TAG, "frame2jpg failed for %s", filename);
        return ESP_FAIL;
    }

    esp_err_t ret = sdcard_write_binary(filename, jpg_buf, jpg_len);
    free(jpg_buf);
    return ret;
}

static esp_err_t save_threshold_as_jpeg(const uint8_t *threshold_img, size_t img_size,
                                        uint16_t width, uint16_t height,
                                        const char *filename)
{
    if (!sdcard_is_mounted()) {
        return ESP_ERR_INVALID_STATE;
    }

    uint8_t *jpg_buf = NULL;
    size_t jpg_len = 0;
    if (!fmt2jpg((uint8_t *)threshold_img, img_size, width, height,
                 PIXFORMAT_GRAYSCALE, JPG_QUALITY, &jpg_buf, &jpg_len)) {
        ESP_LOGE(TAG, "fmt2jpg failed for %s", filename);
        return ESP_FAIL;
    }

    esp_err_t ret = sdcard_write_binary(filename, jpg_buf, jpg_len);
    free(jpg_buf);
    return ret;
}

// Nearest-neighbor resize for grayscale image
static void resize_grayscale_nn(const uint8_t *src, int src_w, int src_h,
                                uint8_t *dst, int dst_w, int dst_h)
{
    for (int y = 0; y < dst_h; y++) {
        int src_y = (y * src_h) / dst_h;
        if (src_y >= src_h) src_y = src_h - 1;

        for (int x = 0; x < dst_w; x++) {
            int src_x = (x * src_w) / dst_w;
            if (src_x >= src_w) src_x = src_w - 1;

            dst[y * dst_w + x] = src[src_y * src_w + src_x];
        }
    }
}

// ── Camera initialisation ────────────────────────────────────────────────────
static esp_err_t camera_init(void)
{
    if (s_camera_ready) return ESP_OK;

    camera_config_t cfg = {
        .pin_pwdn       = CAM_PIN_PWDN,
        .pin_reset      = CAM_PIN_RESET,
        .pin_xclk       = CAM_PIN_XCLK,
        .pin_sscb_sda   = CAM_PIN_SIOD,
        .pin_sscb_scl   = CAM_PIN_SIOC,
        .pin_d7 = CAM_PIN_D7, .pin_d6 = CAM_PIN_D6,
        .pin_d5 = CAM_PIN_D5, .pin_d4 = CAM_PIN_D4,
        .pin_d3 = CAM_PIN_D3, .pin_d2 = CAM_PIN_D2,
        .pin_d1 = CAM_PIN_D1, .pin_d0 = CAM_PIN_D0,
        .pin_vsync      = CAM_PIN_VSYNC,
        .pin_href       = CAM_PIN_HREF,
        .pin_pclk       = CAM_PIN_PCLK,

        .xclk_freq_hz   = 20000000,
        .ledc_timer     = LEDC_TIMER_0,
        .ledc_channel   = LEDC_CHANNEL_0,
        .pixel_format   = PIXFORMAT_GRAYSCALE,
        .frame_size     = FRAMESIZE_UXGA,
        .jpeg_quality   = 12,
        .fb_count       = 1,
        .fb_location    = CAMERA_FB_IN_PSRAM,
        .grab_mode      = CAMERA_GRAB_WHEN_EMPTY,
    };

    esp_err_t err = esp_camera_init(&cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_camera_init failed: 0x%x", err);
        return err;
    }
    s_camera_ready = true;
    ESP_LOGI(TAG, "Camera initialised (UXGA GRAYSCALE, resized to %dx%d for processing)",
             RESIZE_WIDTH, RESIZE_HEIGHT);
    return ESP_OK;
}

// ── Standard Von Neumann debiasing pass ─────────────────────────────────────
// 00/11 -> discard, 01 -> 0, 10 -> 1
static int vn_pass(const uint8_t *bits, int len, uint8_t *out, int max_out)
{
    int out_idx = 0;
    for (int i = 0; i + 1 < len; i += 2) {
        if (out_idx >= max_out) break;
        if (bits[i] == 0 && bits[i + 1] == 1) {
            out[out_idx++] = 0;
        } else if (bits[i] == 1 && bits[i + 1] == 0) {
            out[out_idx++] = 1;
        }
    }
    return out_idx;
}

static int two_pass_vonneumann(const uint8_t *bits, int len,
                               uint8_t *out, int max_out)
{
    uint8_t *tmp = (uint8_t *)heap_caps_malloc(max_out,
                        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!tmp) tmp = (uint8_t *)malloc(max_out);
    if (!tmp) {
        ESP_LOGE(TAG, "two_pass_vonneumann: tmp buffer alloc failed");
        return -1;
    }

    int pass1_len = vn_pass(bits, len, tmp, max_out);
    int pass2_len = 0;
    if (pass1_len >= 2) {
        pass2_len = vn_pass(tmp, pass1_len, out, max_out);
    }

    free(tmp);
    return pass2_len;
}

int extract_bits_from_image(uint8_t *out_bits, int max_len)
{
    if (camera_init() != ESP_OK) {
        ESP_LOGE(TAG, "Camera init failed");
        return -1;
    }

    ESP_LOGI(TAG, "Capturing frame...");
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        ESP_LOGE(TAG, "esp_camera_fb_get failed");
        return -1;
    }

    int src_w = fb->width;
    int src_h = fb->height;
    int src_size = src_w * src_h;

    ESP_LOGI(TAG, "Captured raw frame: %dx%d (%d bytes)", src_w, src_h, src_size);

    if (sdcard_is_mounted()) {
        if (save_framebuffer_as_jpeg(fb, "original.jpg") != ESP_OK) {
            ESP_LOGW(TAG, "Failed to save original.jpg");
        }
    }

    int proc_w = RESIZE_WIDTH;
    int proc_h = RESIZE_HEIGHT;
    int proc_size = proc_w * proc_h;

    uint8_t *resized_img = (uint8_t *)heap_caps_malloc(proc_size,
                            MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    uint8_t *raw_bits = (uint8_t *)heap_caps_malloc(proc_size,
                            MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    uint8_t *threshold_img = (uint8_t *)heap_caps_malloc(proc_size,
                            MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!resized_img || !raw_bits || !threshold_img) {
        ESP_LOGE(TAG, "resized_img/raw_bits/threshold_img alloc failed — PSRAM required");
        free(resized_img);
        free(raw_bits);
        free(threshold_img);
        esp_camera_fb_return(fb);
        return -1;
    }

    resize_grayscale_nn(fb->buf, src_w, src_h, resized_img, proc_w, proc_h);
    ESP_LOGI(TAG, "Resized frame for processing: %dx%d", proc_w, proc_h);

    if (sdcard_is_mounted()) {
        if (save_threshold_as_jpeg(resized_img, (size_t)proc_size, proc_w, proc_h,
                               "resized.jpg") != ESP_OK) {
            ESP_LOGW(TAG, "Failed to save resized.jpg");
        }
    }
    
    uint8_t max_val = 0;
    for (int i = 0; i < proc_size; i++) {
        if (resized_img[i] > max_val) {
            max_val = resized_img[i];
        }
    }

    uint8_t threshold_value = (uint8_t)(max_val * 85 / 100);

    for (int i = 0; i < proc_size; i++) {
        uint8_t bit = (resized_img[i] >= threshold_value) ? 1 : 0;
        raw_bits[i] = bit;
        threshold_img[i] = bit ? 255 : 0;
    }

    if (sdcard_is_mounted()) {
        if (save_threshold_as_jpeg(threshold_img, (size_t)proc_size, proc_w, proc_h,
                                   "threshold.jpg") != ESP_OK) {
            ESP_LOGW(TAG, "Failed to save threshold.jpg");
        }
    }

    esp_camera_fb_return(fb);
    free(resized_img);
    free(threshold_img);

    int out_len = two_pass_vonneumann(raw_bits, proc_size, out_bits, max_len);
    free(raw_bits);

    if (out_len < 0) {
        ESP_LOGE(TAG, "Von Neumann debiasing failed");
        return -1;
    }

    int ones = 0;
    for (int i = 0; i < out_len; i++) {
        if (out_bits[i]) ones++;
    }
    float uniformity = out_len > 0 ? (float)ones / (float)out_len : 0.0f;

    printf("Extracted bits preview (first 10): ");
    for (int i = 0; i < (out_len > 10 ? 10 : out_len); i++) {
        printf("%d", out_bits[i]);
    }
    printf("\nBit uniformity: %.4f\n", uniformity);
    ESP_LOGI(TAG, "Total extracted bits: %d", out_len);

    return out_len;
}
